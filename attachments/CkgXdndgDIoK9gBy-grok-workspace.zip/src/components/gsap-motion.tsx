import { useRef, type MouseEvent, type ReactNode } from "react";
import { useReducedMotion } from "motion/react";
import { cn } from "@/lib/utils";
import {
  easeOut,
  finePointer,
  gsap,
  registerGsap,
  scrollerOf,
  scrollToId,
  ScrollTrigger,
  useGSAP,
} from "@/lib/gsap";

registerGsap();

export function PageEnter({
  children,
  className,
  replayKey,
}: {
  children: ReactNode;
  className?: string;
  replayKey?: string | number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();

  useGSAP(
    () => {
      const root = ref.current;
      if (!root || reduce) return;
      const items = root.querySelectorAll<HTMLElement>("[data-enter]");
      if (!items.length) return;
      gsap.fromTo(
        items,
        { y: 12 },
        {
          y: 0,
          duration: 0.4,
          stagger: 0.05,
          ease: easeOut,
          clearProps: "transform",
        },
      );
    },
    { scope: ref, dependencies: [reduce, replayKey] },
  );

  return (
    <div ref={ref} className={className}>
      {children}
    </div>
  );
}

export function GsapStagger({
  children,
  className,
  replayKey,
  selector = ":scope > *",
  y = 16,
}: {
  children: ReactNode;
  className?: string;
  replayKey?: string | number;
  selector?: string;
  y?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();

  useGSAP(
    () => {
      const root = ref.current;
      if (!root || reduce) return;
      const items = root.querySelectorAll<HTMLElement>(selector);
      if (!items.length) return;
      gsap.fromTo(
        items,
        { y },
        {
          y: 0,
          duration: 0.4,
          stagger: 0.05,
          ease: easeOut,
          clearProps: "transform",
        },
      );
    },
    { scope: ref, dependencies: [reduce, replayKey, selector, y] },
  );

  return (
    <div ref={ref} className={cn("gsap-stagger", className)}>
      {children}
    </div>
  );
}

export function GsapCount({
  value,
  suffix = "",
  className,
}: {
  value: number;
  suffix?: string;
  className?: string;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const reduce = useReducedMotion();

  useGSAP(
    () => {
      const el = ref.current;
      if (!el) return;
      if (reduce) {
        el.textContent = `${value}${suffix}`;
        return;
      }
      const state = { n: 0 };
      gsap.fromTo(
        state,
        { n: 0 },
        {
          n: value,
          duration: 1.15,
          ease: "power2.out",
          scrollTrigger: {
            trigger: el,
            scroller: scrollerOf(el),
            start: "top 90%",
            once: true,
          },
          onUpdate: () => {
            el.textContent = `${Math.round(state.n)}${suffix}`;
          },
        },
      );
    },
    { dependencies: [value, suffix, reduce] },
  );

  return (
    <span ref={ref} className={className}>
      {value}
      {suffix}
    </span>
  );
}

export function Magnetic({
  children,
  className,
  strength = 8,
}: {
  children: ReactNode;
  className?: string;
  strength?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();

  useGSAP(
    () => {
      const el = ref.current;
      if (!el || reduce || !finePointer()) return;
      const xTo = gsap.quickTo(el, "x", { duration: 0.45, ease: easeOut });
      const yTo = gsap.quickTo(el, "y", { duration: 0.45, ease: easeOut });
      const onMove = (event: PointerEvent) => {
        const box = el.getBoundingClientRect();
        xTo(((event.clientX - box.left) / box.width - 0.5) * strength);
        yTo(((event.clientY - box.top) / box.height - 0.5) * strength);
      };
      const reset = () => {
        xTo(0);
        yTo(0);
        el.style.willChange = "auto";
      };
      const arm = () => {
        el.style.willChange = "transform";
      };
      el.addEventListener("pointerenter", arm);
      el.addEventListener("pointermove", onMove);
      el.addEventListener("pointerleave", reset);
      return () => {
        el.removeEventListener("pointerenter", arm);
        el.removeEventListener("pointermove", onMove);
        el.removeEventListener("pointerleave", reset);
      };
    },
    { dependencies: [reduce, strength] },
  );

  return (
    <div ref={ref} className={className}>
      {children}
    </div>
  );
}

/** ScrollTrigger scene: scrubbed images, split headings, in-page ScrollTo. */
export function ScrollScene({ children, className }: { children: ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();

  useGSAP(
    () => {
      const root = ref.current;
      if (!root) return;
      const scroller = scrollerOf(root);

      if (!reduce) {
        root.querySelectorAll<HTMLElement>("[data-scrub]").forEach((el) => {
          gsap.fromTo(
            el,
            { yPercent: -6, scale: 1.06 },
            {
              yPercent: 6,
              scale: 1,
              ease: "none",
              scrollTrigger: {
                trigger: el.parentElement ?? el,
                scroller,
                start: "top bottom",
                end: "bottom top",
                scrub: 0.5,
                invalidateOnRefresh: true,
              },
            },
          );
        });

        root.querySelectorAll<HTMLElement>("[data-scrub-fade]").forEach((el) => {
          gsap.fromTo(
            el,
            { y: 18 },
            {
              y: 0,
              ease: "none",
              scrollTrigger: {
                trigger: el,
                scroller,
                start: "top 92%",
                end: "top 40%",
                scrub: 0.4,
              },
            },
          );
        });

        ScrollTrigger.batch(root.querySelectorAll("[data-batch]"), {
          scroller,
          start: "top 90%",
          once: true,
          onEnter: (elements) => {
            gsap.fromTo(
              elements,
              { y: 14 },
              { y: 0, duration: 0.4, stagger: 0.05, ease: easeOut, overwrite: "auto", clearProps: "transform" },
            );
          },
        });
      }
    },
    { scope: ref, dependencies: [reduce] },
  );

  function onInPageNav(event: MouseEvent<HTMLDivElement>) {
    const link = (event.target as HTMLElement).closest("a[href^='#']");
    if (!(link instanceof HTMLAnchorElement) || !link.hash) return;
    const id = decodeURIComponent(link.hash.slice(1));
    if (!id || !document.getElementById(id)) return;
    event.preventDefault();
    scrollToId(id);
  }

  return (
    <div ref={ref} className={className} onClick={onInPageNav}>
      {children}
    </div>
  );
}
