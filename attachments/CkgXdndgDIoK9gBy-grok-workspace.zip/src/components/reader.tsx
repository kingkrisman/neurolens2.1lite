import { Fragment, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import {
  Bookmark,
  BookOpenText,
  ChevronLeft,
  ChevronRight,
  ChevronsDown,
  Copy,
  Download,
  Focus,
  Highlighter,
  Languages,
  MoreHorizontal,
  Pause,
  Play,
  Settings2,
  SpellCheck,
  StickyNote,
  Volume2,
  VolumeX,
} from "lucide-react";
import { processBionicText } from "@/lib/bionic";
import { simplifyText } from "@/lib/text-simplifier";
import { evaluateScheme, formatContrastRatio } from "@/lib/contrast";
import { FONT_CLASS, TINT_CLASS } from "@/lib/types";
import { useAppStore } from "@/lib/store";
import { tapFeedback } from "@/lib/feedback";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/field";
import { IconSwap } from "@/components/ui/icon-swap";
import { Progress } from "@/components/ui/surfaces";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Sheet } from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ReaderControls } from "@/components/reader-controls";
import { RecommendationBanner } from "@/components/recommendation-banner";
import { SpeedReader } from "@/components/speed-reader";
import { cn, wordCount } from "@/lib/utils";
import { announce } from "@/lib/announce";
import { useReadingTracker } from "@/lib/adaptive/use-reading-tracker";
import { autoScrollDeltaPx, resolveRhythmCurve, tokenContextAtProgress } from "@/lib/rhythm";
import { splitSentenceSpans } from "@/lib/sentences";
import { ReadingFeelBar } from "@/components/reading-feel";
import { PdfPageCanvas, ReaderPager } from "@/components/pdf-pager";
import { splitPdfPages, joinPdfPages } from "@/lib/pdf-pages";
import { detectChapters, joinTextChapters, splitTextChapters } from "@/lib/chapters";
import { chapterRole, isTitlePage, parseBlocks } from "@/lib/blocks";
import { WordRun } from "@/components/word-run";
import { WordCard } from "@/components/word-card";
import { chunkByMinutes, wordAtChar } from "@/lib/word-markup";
import { copyReading, downloadReading } from "@/lib/reading-export";
import { easeOut, gsap, registerGsap, useGSAP } from "@/lib/gsap";
import { useReducedMotion } from "motion/react";

registerGsap();

export function Reader() {
  const text = useAppStore((s) => s.text);
  const sourceKind = useAppStore((s) => s.sourceKind);
  const pdfPage = useAppStore((s) => s.pdfPage);
  const pdfPageCount = useAppStore((s) => s.pdfPageCount);
  const setPdfPage = useAppStore((s) => s.setPdfPage);
  const chapterIndex = useAppStore((s) => s.chapterIndex);
  const chapterCount = useAppStore((s) => s.chapterCount);
  const setChapter = useAppStore((s) => s.setChapter);
  const profile = useAppStore((s) => s.profile);
  const setProfile = useAppStore((s) => s.setProfile);
  const mode = useAppStore((s) => s.mode);
  const controlsOpen = useAppStore((s) => s.controlsOpen);
  const setControlsOpen = useAppStore((s) => s.setControlsOpen);
  const autoScrolling = useAppStore((s) => s.autoScrolling);
  const setAutoScrolling = useAppStore((s) => s.setAutoScrolling);
  const targetWpm = useAppStore((s) => s.targetWpm);
  const currentWpm = useAppStore((s) => s.reading.currentWpm);
  const progress = useAppStore((s) => s.reading.progress);
  const pauses = useAppStore((s) => s.reading.pauses.length);
  const rereads = useAppStore((s) => s.reading.rereads.length);
  const highlights = useAppStore((s) => s.highlights);
  const toggleHighlight = useAppStore((s) => s.toggleHighlight);
  const toggleBookmark = useAppStore((s) => s.toggleBookmark);
  const bookmarks = useAppStore((s) => s.bookmarks);

  const scrollRef = useRef<HTMLDivElement>(null);
  const toolbarRef = useRef<HTMLDivElement>(null);
  const reduceMotion = useReducedMotion();
  const startReading = useAppStore((s) => s.startReading);
  const [activeLine, setActiveLine] = useState<number | null>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [rsvpOpen, setRsvpOpen] = useState(false);
  const [noteOpen, setNoteOpen] = useState(false);
  const [note, setNote] = useState("");
  const [simplifyOpen, setSimplifyOpen] = useState(false);
  const [lookup, setLookup] = useState<string | null>(null);
  const [activeWord, setActiveWord] = useState<{ line: number; index: number } | null>(null);
  const [chunkOn, setChunkOn] = useState(false);
  const [chunkIndex, setChunkIndex] = useState(0);
  const speechIndex = useRef(0);
  const programmaticScroll = useRef(false);
  const didAnnounceScroll = useRef(false);

  const pdfPages = useMemo(
    () => (sourceKind === "pdf" ? splitPdfPages(text) : []),
    [sourceKind, text],
  );
  const textChapters = useMemo(
    () => (sourceKind === "text" ? splitTextChapters(text) : []),
    [sourceKind, text],
  );
  const pdfChapters = useMemo(
    () => (sourceKind === "pdf" ? detectChapters(pdfPages) : []),
    [sourceKind, pdfPages],
  );
  const chapters = sourceKind === "pdf" ? pdfChapters : textChapters.map((chapter, index) => ({
    title: chapter.title,
    startPage: index + 1,
    endPage: index + 1,
  }));
  const pageCount = pdfPageCount || pdfPages.length;
  const paged = sourceKind === "pdf" && pageCount > 0;
  const chaptered = chapterCount > 1;
  const pageText = paged
    ? (pdfPages[Math.max(0, pdfPage - 1)] ?? "")
    : chaptered
      ? (textChapters[Math.max(0, chapterIndex - 1)]?.body ?? text)
      : text;
  const chunks = useMemo(
    () => (chunkOn ? chunkByMinutes(pageText, targetWpm, 3) : [pageText]),
    [chunkOn, pageText, targetWpm],
  );
  const viewText = chunks[Math.min(chunkIndex, Math.max(0, chunks.length - 1))] ?? pageText;

  const blocks = useMemo(() => parseBlocks(viewText), [viewText]);
  const titlePage =
    isTitlePage(blocks) ||
    (chaptered && chapterRole(chapters[Math.max(0, chapterIndex - 1)]?.title ?? "") === "front");
  const words = useMemo(() => viewText.trim().split(/\s+/).filter(Boolean), [viewText]);
  useReadingTracker(scrollRef, words.length);

  const lines = useMemo(() => {
    const list: {
      text: string;
      html: string;
      lineIdx: number;
      blockIndex: number;
      itemIndex: number;
    }[] = [];
    blocks.forEach((block, blockIndex) => {
      const sources = block.items?.map((item) => item.text) ?? (block.text ? [block.text] : []);
      sources.forEach((source, itemIndex) => {
        splitSentenceSpans(source).forEach((span, index) => {
          const full = span.trim();
          if (!full) return;
          list.push({
            text: full,
            html:
              profile.bionicStrength > 0
                ? processBionicText(full, profile.bionicStrength, profile.rhythmOptimization)
                : full,
            lineIdx: blockIndex * 1000 + itemIndex * 40 + index,
            blockIndex,
            itemIndex,
          });
        });
      });
    });
    return list;
  }, [blocks, profile.bionicStrength, profile.rhythmOptimization]);

  useEffect(() => {
    const key = text.trim().slice(0, 40) || "default";
    setNote(localStorage.getItem(`neurolens-note-${key}`) || "");
  }, [text]);

  useEffect(() => {
    const key = text.trim().slice(0, 40) || "default";
    const timer = window.setTimeout(() => {
      localStorage.setItem(`neurolens-note-${key}`, note);
    }, 350);
    return () => window.clearTimeout(timer);
  }, [note, text]);

  function speakAt(index: number) {
    if (!("speechSynthesis" in window)) return;
    if (index < 0 || index >= lines.length) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }
    const item = lines[index];
    speechIndex.current = index;
    setActiveLine(item.lineIdx);
    document.getElementById(`line-${item.lineIdx}`)?.scrollIntoView({ behavior: "smooth", block: "center" });
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(item.text);
    utterance.rate = 0.95;
    utterance.onboundary = (event) => {
      if (event.charIndex == null) return;
      setActiveWord({ line: item.lineIdx, index: wordAtChar(item.text, event.charIndex) });
    };
    utterance.onend = () => {
      if (speechIndex.current === index) speakAt(index + 1);
    };
    utterance.onerror = () => setIsSpeaking(false);
    window.speechSynthesis.speak(utterance);
  }

  function toggleSpeech() {
    if (!("speechSynthesis" in window)) {
      toast.error("Speech is not available here");
      return;
    }
    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      announce("Stopped reading aloud");
      return;
    }
    setIsSpeaking(true);
    announce("Reading aloud");
    const start = activeLine == null ? 0 : Math.max(0, lines.findIndex((line) => line.lineIdx === activeLine));
    speakAt(start);
  }

  useEffect(() => () => {
    if ("speechSynthesis" in window) window.speechSynthesis.cancel();
  }, []);

  useEffect(() => {
    setActiveLine(null);
    const node = scrollRef.current;
    if (node) node.scrollTop = 0;
    if (chaptered && chapterIndex > 0) {
      const title = chapters[chapterIndex - 1]?.title;
      if (title) announce(title);
    } else if (paged) {
      announce(`Page ${pdfPage} of ${pageCount}`);
    }
  }, [pdfPage, chapterIndex, pageText]);

  useEffect(() => {
    setChunkIndex(0);
  }, [pageText, chunkOn]);

  useEffect(() => {
    const node = scrollRef.current;
    if (!node || isSpeaking) return;
    if (!profile.readingMask && !profile.wordGuide) return;
    const io = new IntersectionObserver(
      (entries) => {
        const mid = node.getBoundingClientRect().top + node.clientHeight * 0.42;
        const hit = entries
          .filter((entry) => entry.isIntersecting)
          .sort(
            (a, b) =>
              Math.abs(a.boundingClientRect.top - mid) - Math.abs(b.boundingClientRect.top - mid),
          )[0];
        const id = hit?.target.id;
        if (!id?.startsWith("line-")) return;
        const lineIdx = Number(id.slice(5));
        if (Number.isFinite(lineIdx)) setActiveLine(lineIdx);
      },
      { root: node, rootMargin: "-38% 0px -50% 0px", threshold: [0, 0.4, 1] },
    );
    node.querySelectorAll(".reading-line").forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [viewText, isSpeaking, profile.readingMask, profile.wordGuide, lines.length]);

  useEffect(() => {
    if (!paged && !chaptered) return;
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.tagName === "SELECT" || target.isContentEditable)) return;
      if (event.key === "ArrowRight" || event.key === "PageDown") {
        event.preventDefault();
        if (chaptered) setChapter(chapterIndex < 1 ? 1 : chapterIndex + 1);
        else setPdfPage(pdfPage + 1);
      } else if (event.key === "ArrowLeft" || event.key === "PageUp") {
        event.preventDefault();
        if (chaptered) setChapter(chapterIndex - 1);
        else setPdfPage(pdfPage - 1);
      } else if (paged && event.key === "]") {
        event.preventDefault();
        setPdfPage(pdfPage + 1);
      } else if (paged && event.key === "[") {
        event.preventDefault();
        setPdfPage(pdfPage - 1);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [paged, chaptered, pdfPage, chapterIndex, setPdfPage, setChapter]);

  const simplified = useMemo(() => simplifyText(viewText), [viewText]);
  const markKey = text.trim().slice(0, 48) || "default";
  const marked = highlights[markKey] ?? [];
  const bookmarked = bookmarks.some((item) => item.content === text);
  const rhythmCurve = resolveRhythmCurve(profile.rhythmCurve, profile.rhythmOptimization);
  const contrast = evaluateScheme(profile.theme, profile.fontSize);

  useEffect(() => {
    const node = scrollRef.current;
    if (!node || !autoScrolling) {
      didAnnounceScroll.current = false;
      return;
    }
    let frame = 0;
    let last = performance.now();
    let carry = 0;

    const stopForUser = () => {
      if (programmaticScroll.current) return;
      setAutoScrolling(false);
    };

    const maxAtStart = node.scrollHeight - node.clientHeight - node.scrollTop;
    if (maxAtStart < 8) {
      setAutoScrolling(false);
      toast("You’re already at the end of the page");
      return;
    }

    if (!didAnnounceScroll.current) {
      toast.success(`Scrolling at ${targetWpm} WPM`);
      didAnnounceScroll.current = true;
    }

    const step = (now: number) => {
      const dtSec = Math.min(0.05, (now - last) / 1000);
      last = now;
      const maxScroll = node.scrollHeight - node.clientHeight;
      const remainingPx = maxScroll - node.scrollTop;
      if (maxScroll <= 1 || remainingPx <= 2) {
        setAutoScrolling(false);
        toast.success("End of the page");
        return;
      }
      const localProgress = node.scrollTop / maxScroll;
      const remainingWords = Math.max(1, Math.round((1 - localProgress) * words.length));
      const focus = tokenContextAtProgress(words, localProgress);
      carry += autoScrollDeltaPx({
        remainingPx,
        remainingWords,
        targetWpm,
        dtSec,
        focusToken: focus.token,
        nextToken: focus.next,
        curve: rhythmCurve,
      });
      const px = Math.trunc(carry);
      if (px >= 1) {
        programmaticScroll.current = true;
        node.scrollTop += px;
        programmaticScroll.current = false;
        carry -= px;
      }
      const line = lines[Math.min(lines.length - 1, Math.max(0, Math.floor(localProgress * lines.length)))];
      if (line) setActiveLine(line.lineIdx);
      if (node.scrollTop + node.clientHeight >= node.scrollHeight - 4) {
        setAutoScrolling(false);
        toast.success("End of the page");
        return;
      }
      frame = requestAnimationFrame(step);
    };

    frame = requestAnimationFrame(step);
    node.addEventListener("wheel", stopForUser, { passive: true });
    node.addEventListener("pointerdown", stopForUser);
    node.addEventListener("touchmove", stopForUser, { passive: true });
    return () => {
      cancelAnimationFrame(frame);
      node.removeEventListener("wheel", stopForUser);
      node.removeEventListener("pointerdown", stopForUser);
      node.removeEventListener("touchmove", stopForUser);
    };
  }, [autoScrolling, targetWpm, words, setAutoScrolling, rhythmCurve, lines]);

  function toggleAutoScroll() {
    if (autoScrolling) {
      setAutoScrolling(false);
      announce("Auto-scroll paused");
      return;
    }
    const node = scrollRef.current;
    const remaining = node ? node.scrollHeight - node.clientHeight - node.scrollTop : 0;
    if (!node || remaining < 8) {
      toast("You’re already at the end of the page");
      return;
    }
    tapFeedback("start");
    setAutoScrolling(true);
  }

  const onRsvpProgress = useCallback(
    (index: number) => {
      const node = scrollRef.current;
      if (!node || words.length < 2) return;
      const max = node.scrollHeight - node.clientHeight;
      if (max <= 1) return;
      programmaticScroll.current = true;
      node.scrollTop = (index / (words.length - 1)) * max;
      programmaticScroll.current = false;
    },
    [words.length],
  );

  const sessionTitle = useAppStore((s) => s.sessions[0]?.title);
  const readingTitle = sessionTitle || text.split(/\n/).find((line) => line.trim())?.slice(0, 80) || "Untitled reading";

  useGSAP(
    () => {
      const bar = toolbarRef.current;
      if (!bar || reduceMotion) return;
      gsap.from(bar, { y: 22, opacity: 0, duration: 0.5, delay: 0.12, ease: easeOut });
    },
    { dependencies: [reduceMotion] },
  );

  return (
    <div
      className={cn(
        "relative flex h-full min-h-0 flex-1 flex-col",
        TINT_CLASS[profile.tint],
        rhythmCurve === "breath" && "rhythm-breath",
        autoScrolling && "is-autoscrolling",
      )}
    >
      <Sheet open={controlsOpen} onOpenChange={setControlsOpen} title="Reading options">
        <ReaderControls onClose={() => setControlsOpen(false)} />
      </Sheet>

      <div ref={scrollRef} className="reader-scroll min-h-0 flex-1 overflow-y-auto">
        <article
          aria-labelledby="reading-title"
          className={cn(
            "mx-auto max-w-2xl px-5 pt-24 pb-16 sm:px-8 sm:pt-28 sm:pb-20",
            FONT_CLASS[profile.fontFamily],
            profile.focusHighlight && "focus-highlight",
            profile.readingMask && "reading-mask",
            profile.align === "justify" && !titlePage && "text-justify",
            titlePage && "is-title-page",
          )}
          style={{
            fontSize: profile.fontSize,
            lineHeight: profile.lineHeight,
            letterSpacing: `${profile.letterSpacing}em`,
            wordSpacing: `${profile.wordSpacing}em`,
          }}
        >
          <h1 id="reading-title" className="sr-only">
            {readingTitle}
          </h1>
          <p className="mb-8 text-xs font-medium tracking-wide text-muted uppercase">
            <span className="sr-only">
              {chaptered && chapterIndex > 0 ? `Chapter ${chapterIndex} of ${chapterCount}. ` : ""}
              {paged ? `Page ${pdfPage} of ${pageCount}. ` : ""}
              {wordCount(viewText).toLocaleString()} words
              {paged || chaptered ? " in this section." : "."}
              {mode === "adaptive" ? " Adaptive is watching pace, pauses, and rereads." : ""}
              {` Contrast ${formatContrastRatio(contrast.body)}, ${contrast.bodyLevel}.`}
              {pauses > 0 ? ` ${pauses} pause${pauses === 1 ? "" : "s"}.` : ""}
              {rereads > 0 ? ` ${rereads} reread${rereads === 1 ? "" : "s"}.` : ""}
              {autoScrolling ? ` Auto-scrolling at ${targetWpm} words per minute.` : ""}
            </span>
            <span aria-hidden="true">
              {chaptered && chapterIndex > 0 ? `Chapter ${chapterIndex} of ${chapterCount} · ` : ""}
              {paged ? `Page ${pdfPage} of ${pageCount} · ` : ""}
              {wordCount(viewText).toLocaleString()} words
              {mode === "adaptive" ? (
                <>
                  {" · "}
                  <span className="watching-dot" />
                  {" watching"}
                </>
              ) : null}
              {` · ${formatContrastRatio(contrast.body)} ${contrast.bodyLevel}`}
              {pauses > 0 ? ` · ${pauses} pause${pauses === 1 ? "" : "s"}` : ""}
              {rereads > 0 ? ` · ${rereads} reread${rereads === 1 ? "" : "s"}` : ""}
              {autoScrolling ? ` · scrolling ${targetWpm}` : ""}
            </span>
          </p>
          {chaptered && chapterIndex > 0 && !titlePage ? (
            <h2 className="mb-6 font-serif text-3xl">{chapters[chapterIndex - 1]?.title}</h2>
          ) : null}
          {paged ? <PdfPageCanvas page={pdfPage} /> : null}
          {paged && blocks.length === 0 ? (
            <p className="mb-6 text-sm leading-relaxed text-muted">
              This page is an image. The drawing is above; there isn’t selectable text to format.
            </p>
          ) : null}
          {blocks.map((block, blockIndex) => {
            const renderSentences = (itemIndex = 0) => {
              const sentenceNodes = lines.filter(
                (line) => line.blockIndex === blockIndex && line.itemIndex === itemIndex,
              );
              return sentenceNodes.map((line, index) => (
                <Fragment key={line.lineIdx}>
                  {index > 0 ? " " : null}
                  <span
                    id={`line-${line.lineIdx}`}
                    className={cn(
                      "reading-line cursor-pointer",
                      rhythmCurve !== "steady" && /[.!?…]["'”’)]*$/.test(line.text.trim()) && "rhythm-cadence",
                      (activeLine === line.lineIdx || (autoScrolling && activeLine === line.lineIdx)) && "active",
                      marked.includes(line.lineIdx) && "marked",
                    )}
                    onClick={() => {
                      if (isSpeaking) {
                        const found = lines.findIndex((item) => item.lineIdx === line.lineIdx);
                        if (found !== -1) speakAt(found);
                      } else if (activeLine === line.lineIdx) {
                        toggleHighlight(line.lineIdx);
                      } else {
                        setActiveLine(line.lineIdx);
                      }
                    }}
                  >
                    <WordRun
                      text={line.text}
                      html={line.html}
                      lineIdx={line.lineIdx}
                      activeWord={activeWord}
                      guides={{
                        syllables: Boolean(profile.syllables),
                        letterGuide: Boolean(profile.letterGuide),
                        wordGuide: Boolean(profile.wordGuide),
                        lookup: Boolean(profile.lookup),
                      }}
                      bionic={profile.bionicStrength}
                      rhythm={profile.rhythmOptimization}
                      onWord={(lineId, index, word, openLookup) => {
                        setActiveLine(lineId);
                        setActiveWord({ line: lineId, index });
                        if (openLookup && profile.lookup) setLookup(word);
                      }}
                    />
                  </span>
                </Fragment>
              ));
            };

            if (block.kind === "list" && block.items?.length) {
              const ListTag = block.ordered ? "ol" : "ul";
              return (
                <ListTag
                  key={blockIndex}
                  className={cn("reading-list reading-block mb-6", block.ordered ? "is-ordered" : "is-bulleted")}
                >
                  {block.items.map((_, itemIndex) => (
                    <li key={itemIndex}>
                      <span className="min-w-0">{renderSentences(itemIndex)}</span>
                    </li>
                  ))}
                </ListTag>
              );
            }

            if (block.kind === "title") {
              return (
                <h2 key={blockIndex} className="reading-title reading-block mb-6 font-serif">
                  {renderSentences()}
                </h2>
              );
            }
            if (block.kind === "kicker") {
              return (
                <p key={blockIndex} className="reading-kicker reading-block mb-3">
                  {renderSentences()}
                </p>
              );
            }
            if (block.kind === "heading") {
              return (
                <h3 key={blockIndex} className="reading-heading reading-block mb-4 mt-8 font-serif text-2xl">
                  {renderSentences()}
                </h3>
              );
            }
            if (block.kind === "quote") {
              return (
                <blockquote key={blockIndex} className="reading-quote reading-block mb-6">
                  {renderSentences()}
                </blockquote>
              );
            }
            return (
              <p
                key={blockIndex}
                className={cn("reading-block mb-6", block.kind === "lead" && "reading-lead")}
              >
                {renderSentences()}
              </p>
            );
          })}
        </article>
      </div>

      <div className="reader-dock pointer-events-none shrink-0 px-3 pt-2 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
        <div className="mx-auto flex max-w-3xl flex-col items-center gap-2">
        <ReadingFeelBar />
        <RecommendationBanner />
        {lookup ? (
          <div className="pointer-events-auto w-full max-w-sm">
            <WordCard word={lookup} onClose={() => setLookup(null)} />
          </div>
        ) : null}
        <div
          ref={toolbarRef}
          role="toolbar"
          aria-label="Reading tools"
          className="material-surface pointer-events-auto flex max-w-full items-center gap-1 overflow-x-auto rounded-lg p-1.5 shadow-float"
        >
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="icon-sm" onClick={() => setControlsOpen(true)} aria-label="Reading options">
                <Settings2 size={16} />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Options</TooltipContent>
          </Tooltip>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon-sm" aria-label="Reading guides" aria-pressed={Boolean(profile.syllables || profile.letterGuide || profile.wordGuide || profile.readingMask)}>
                <Focus size={16} />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start">
              <DropdownMenuItem onSelect={() => setProfile({ ...profile, syllables: !profile.syllables })}>
                <SpellCheck size={14} />
                {profile.syllables ? "Syllables on" : "Syllables"}
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={() => setProfile({ ...profile, letterGuide: !profile.letterGuide })}>
                <BookOpenText size={14} />
                {profile.letterGuide ? "Letter guide on" : "Letter guide"}
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={() => setProfile({ ...profile, wordGuide: !profile.wordGuide })}>
                <Highlighter size={14} />
                {profile.wordGuide ? "Word highlight on" : "Word highlight"}
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={() => setProfile({ ...profile, readingMask: !profile.readingMask })}>
                <Focus size={14} />
                {profile.readingMask ? "Focus window on" : "Focus window"}
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={() => setProfile({ ...profile, lookup: !profile.lookup })}>
                <BookOpenText size={14} />
                {profile.lookup ? "Definitions on" : "Tap for definition"}
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={() => setProfile({ ...profile, dimChrome: !profile.dimChrome })}>
                {profile.dimChrome ? "Chrome dimmed" : "Dim the chrome"}
              </DropdownMenuItem>
              <DropdownMenuItem
                onSelect={() => {
                  setChunkOn((value) => !value);
                  setChunkIndex(0);
                }}
              >
                {chunkOn ? "Exit chunks" : "Break into 3-minute chunks"}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon-sm"
                onClick={toggleBookmark}
                aria-label={bookmarked ? "Remove bookmark" : "Bookmark"}
                aria-pressed={bookmarked}
              >
                <Bookmark size={16} className={bookmarked ? "fill-current" : undefined} />
              </Button>
            </TooltipTrigger>
            <TooltipContent>{bookmarked ? "Remove bookmark" : "Bookmark"}</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon-sm"
                onClick={toggleSpeech}
                aria-label={isSpeaking ? "Stop listening" : "Listen"}
                aria-pressed={isSpeaking}
              >
                <IconSwap active={isSpeaking} ActiveIcon={VolumeX} InactiveIcon={Volume2} />
              </Button>
            </TooltipTrigger>
            <TooltipContent>{isSpeaking ? "Stop listening" : "Listen"}</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant={autoScrolling ? "default" : "ghost"}
                size="icon-sm"
                onClick={toggleAutoScroll}
                aria-label={autoScrolling ? "Pause auto-scroll" : "Auto-scroll"}
                aria-pressed={autoScrolling}
              >
                <IconSwap active={autoScrolling} ActiveIcon={Pause} InactiveIcon={ChevronsDown} />
              </Button>
            </TooltipTrigger>
            <TooltipContent>{autoScrolling ? "Pause scroll" : "Auto-scroll"}</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon-sm"
                onClick={() => setRsvpOpen(true)}
                aria-label="Speed reader"
              >
                <Play size={16} className="play-icon" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Speed reader</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="icon-sm" onClick={() => setSimplifyOpen(true)} aria-label="Simplify">
                <Languages size={16} />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Simplify</TooltipContent>
          </Tooltip>
          <div className="hidden sm:contents">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon-sm" onClick={() => setNoteOpen(true)} aria-label="Note">
                  <StickyNote size={16} />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Quick note</TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon-sm"
                  onClick={async () => {
                    await copyReading(text, profile, targetWpm, readingTitle);
                    toast.success("Copied with formatting");
                  }}
                  aria-label="Copy"
                >
                  <Copy size={16} />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Copy</TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon-sm"
                  onClick={() => {
                    downloadReading(text, profile, targetWpm, readingTitle);
                    toast.success("Downloaded with formatting");
                  }}
                  aria-label="Download"
                >
                  <Download size={16} />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Download</TooltipContent>
            </Tooltip>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon-sm" className="sm:hidden" aria-label="More actions">
                <MoreHorizontal size={16} />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onSelect={() => setNoteOpen(true)}>Quick note</DropdownMenuItem>
              <DropdownMenuItem
                onSelect={async () => {
                  await copyReading(text, profile, targetWpm, readingTitle);
                  toast.success("Copied with formatting");
                }}
              >
                Copy text
              </DropdownMenuItem>
              <DropdownMenuItem
                onSelect={() => {
                  downloadReading(text, profile, targetWpm, readingTitle);
                  toast.success("Downloaded with formatting");
                }}
              >
                Download
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          {paged || chaptered ? (
            <>
              <div className="mx-0.5 hidden h-5 w-px bg-fg/12 sm:block" aria-hidden />
              <ReaderPager
                page={paged ? pdfPage : chapterIndex}
                pageCount={paged ? pageCount : 0}
                chapter={chapterIndex}
                chapterCount={chapterCount}
                chapters={chapters}
                onPage={setPdfPage}
                onChapter={setChapter}
              />
            </>
          ) : null}
          {chunkOn && chunks.length > 1 ? (
            <div className="mx-1 flex items-center gap-1 text-[11px] tabular-nums text-muted">
              <Button variant="ghost" size="icon-sm" disabled={chunkIndex <= 0} onClick={() => setChunkIndex((i) => Math.max(0, i - 1))} aria-label="Previous chunk">
                <ChevronLeft size={16} />
              </Button>
              <span>
                {chunkIndex + 1}/{chunks.length}
              </span>
              <Button variant="ghost" size="icon-sm" disabled={chunkIndex >= chunks.length - 1} onClick={() => setChunkIndex((i) => Math.min(chunks.length - 1, i + 1))} aria-label="Next chunk">
                <ChevronRight size={16} />
              </Button>
            </div>
          ) : null}
          <div className="mx-1 hidden items-center gap-1.5 border-l border-border pr-2 pl-2 text-[11px] tabular-nums text-muted sm:flex">
            <span>Target {targetWpm}</span>
            <span className="opacity-40">·</span>
            <span>Now {currentWpm ?? "—"}</span>
          </div>
          <div className="mx-2 hidden w-20 sm:block">
            <Progress value={Math.round(progress * 100)} label="Reading progress" />
          </div>
          <span className="hidden pr-2 text-xs tabular-nums text-muted sm:inline">
            {Math.round(progress * 100)}%
          </span>
        </div>
        </div>
      </div>

      <SpeedReader open={rsvpOpen} onOpenChange={setRsvpOpen} words={words} onProgress={onRsvpProgress} />

      <Dialog open={simplifyOpen} onOpenChange={setSimplifyOpen}>
        <DialogContent>
          <DialogTitle className="mb-2 text-lg font-medium">Simpler wording</DialogTitle>
          <DialogDescription className="mb-4 text-sm text-muted">
            A local rewrite. Dense words become plainer ones. Nothing leaves this device.
          </DialogDescription>
          <p className="text-xs tracking-wide text-muted uppercase">
            {simplified.complexity} · grade {simplified.originalGrade}
            {simplified.simplifiedGrade !== simplified.originalGrade ? ` → ${simplified.simplifiedGrade}` : ""}
            {simplified.replacements > 0 ? ` · ${simplified.replacements} swap${simplified.replacements === 1 ? "" : "s"}` : ""}
          </p>
          <p className="mt-3 max-h-64 overflow-y-auto text-sm leading-relaxed">
            {simplified.simplified}
          </p>
          <div className="mt-5 flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setSimplifyOpen(false)}>
              Keep original
            </Button>
            <Button
              disabled={simplified.replacements === 0 && simplified.simplified === pageText.trim()}
              onClick={() => {
                tapFeedback("ok");
                if (paged) {
                  const next = [...pdfPages];
                  next[Math.max(0, pdfPage - 1)] = simplified.simplified;
                  startReading(joinPdfPages(next), { title: readingTitle, kind: "pdf", pdfPage });
                } else if (chaptered) {
                  const next = [...textChapters];
                  const index = Math.max(0, chapterIndex - 1);
                  if (next[index]) next[index] = { ...next[index], body: simplified.simplified };
                  startReading(joinTextChapters(next), { title: readingTitle, kind: "text", chapter: chapterIndex });
                } else {
                  startReading(simplified.simplified);
                }
                setSimplifyOpen(false);
                toast.success("Using the simpler version");
              }}
            >
              Use this version
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={noteOpen} onOpenChange={setNoteOpen}>
        <DialogContent>
          <DialogTitle className="mb-3 text-lg font-medium">Quick note</DialogTitle>
          <DialogDescription className="mb-4 text-sm text-muted">
            Saved to this session on this device.
          </DialogDescription>
          <Textarea
            value={note}
            onChange={(event) => setNote(event.target.value)}
            placeholder="Capture a thought while you read…"
            aria-label="Quick note"
            className="min-h-40 rounded-md bg-bg px-3 py-2 shadow-border"
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
