import { useRef, useState } from "react";
import { toast } from "sonner";
import { FONT_CHOICES, FONT_CLASS, NAMED_PRESETS, READING_PROFILES, RHYTHM_CHOICES, type ReadingMode } from "@/lib/types";
import { useAppStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Label, Slider, Switch } from "@/components/ui/field";
import { Panel, PanelHeader, PanelWell } from "@/components/ui/surfaces";
import { SchemePicker, ContrastMeter } from "@/components/scheme-picker";
import { ContrastLab } from "@/components/contrast-lab";
import { AccessibleBionic } from "@/components/accessible-bionic";
import { processBionicText } from "@/lib/bionic";
import { DEMO_SENTENCE } from "@/lib/samples";
import { openingSoundEnabled, setOpeningSoundEnabled } from "@/lib/opening-sound";
import { cn } from "@/lib/utils";
import { PageEnter } from "@/components/gsap-motion";

export function SettingsPanel() {
  const clearData = useAppStore((s) => s.clearData);
  const applySavedProfile = useAppStore((s) => s.applySavedProfile);
  const saveCurrentProfile = useAppStore((s) => s.saveCurrentProfile);
  const savedProfiles = useAppStore((s) => s.savedProfiles);
  const deleteSavedProfile = useAppStore((s) => s.deleteSavedProfile);
  const profile = useAppStore((s) => s.profile);
  const setProfile = useAppStore((s) => s.setProfile);
  const mode = useAppStore((s) => s.mode);
  const setMode = useAppStore((s) => s.setMode);
  const targetWpm = useAppStore((s) => s.targetWpm);
  const setTargetWpm = useAppStore((s) => s.setTargetWpm);
  const [holding, setHolding] = useState(false);
  const [sound, setSound] = useState(() => (typeof window === "undefined" ? true : openingSoundEnabled()));
  const [profileName, setProfileName] = useState("");
  const timer = useRef<number | null>(null);

  function startHold() {
    setHolding(true);
    timer.current = window.setTimeout(() => {
      clearData();
      setHolding(false);
      toast.success("Local data cleared");
    }, 2000);
  }

  function endHold() {
    setHolding(false);
    if (timer.current) window.clearTimeout(timer.current);
  }

  const preview = profile.bionicStrength > 0 ? processBionicText(DEMO_SENTENCE, profile.bionicStrength, profile.rhythmOptimization) : DEMO_SENTENCE;

  return (
    <PageEnter className="mx-auto h-full max-w-3xl px-4 py-10 sm:px-8 sm:py-14">
      <h1 data-enter className="text-5xl">Settings</h1>
      <p data-enter className="mt-3 text-muted">
        These controls write to the reader immediately. Nothing is stored off this device.
      </p>

      <div data-enter className="mt-10 space-y-3">
        <Panel>
          <PanelHeader title="Mode" description="A named starting point. You can still tune every slider below." />
          <PanelWell className="grid grid-cols-2 gap-1.5 p-2">
            {(Object.keys(READING_PROFILES) as ReadingMode[]).map((id) => {
              const selected = mode === id;
              return (
                <button
                  key={id}
                  type="button"
                  aria-pressed={selected}
                  onClick={() => setMode(id)}
                  className={cn(
                    "rounded-md px-3 py-3 text-left text-sm font-medium transition-[background-color,transform] duration-[140ms] ease-[var(--ease-out)] active:scale-[0.97]",
                    selected ? "bg-fg text-primary-fg" : "hover:bg-fg/8",
                  )}
                >
                  {READING_PROFILES[id].name}
                </button>
              );
            })}
          </PanelWell>
        </Panel>

        <Panel>
          <PanelHeader title="Live preview" description="The sentence updates as you move the sliders." />
          <PanelWell className="px-5 py-6">
            <p
              className={cn("text-left leading-relaxed", FONT_CLASS[profile.fontFamily])}
              style={{
                fontSize: profile.fontSize,
                lineHeight: profile.lineHeight,
                letterSpacing: `${profile.letterSpacing}em`,
                wordSpacing: `${profile.wordSpacing}em`,
              }}
            >
              {profile.bionicStrength > 0 ? (
                <AccessibleBionic text={DEMO_SENTENCE} html={preview} />
              ) : (
                DEMO_SENTENCE
              )}
            </p>
          </PanelWell>
        </Panel>

        <Panel>
          <PanelHeader title="Color" description="Paper, night, and quieter rooms. Contrast is measured at your type size." />
          <PanelWell className="px-4 py-4">
            <SchemePicker value={profile.theme} onChange={(theme) => setProfile({ ...profile, theme })} />
            <ContrastMeter theme={profile.theme} fontSize={profile.fontSize} />
          </PanelWell>
        </Panel>

        <Panel>
          <PanelWell className="px-4 py-5">
            <ContrastLab />
          </PanelWell>
        </Panel>

        <Panel>
          <PanelHeader title="Type" description="Pick a face, then set size and spacing. Dyslexia-friendly fonts sit in this same list." />
          <PanelWell className="space-y-5 p-3">
            <div className="grid grid-cols-2 gap-1.5">
              {FONT_CHOICES.map((font) => {
                const selected = profile.fontFamily === font.id;
                return (
                  <button
                    key={font.id}
                    type="button"
                    aria-pressed={selected}
                    onClick={() => setProfile({ ...profile, fontFamily: font.id })}
                    className={cn(
                      "rounded-md px-3 py-3 text-left transition-[background-color,transform] duration-[140ms] ease-[var(--ease-out)] active:scale-[0.97]",
                      FONT_CLASS[font.id],
                      selected ? "bg-fg text-primary-fg" : "hover:bg-fg/8",
                    )}
                  >
                    <span className="block text-sm font-medium">{font.label}</span>
                    <span className={cn("mt-0.5 block text-xs", selected ? "text-primary-fg/70" : "text-muted")}>
                      {font.hint}
                    </span>
                  </button>
                );
              })}
            </div>
            <div>
              <div className="mb-1 flex items-center justify-between text-sm">
                <Label>Size</Label>
                <span className="tabular-nums text-muted">{profile.fontSize}px</span>
              </div>
              <Slider
                min={14}
                max={28}
                step={1}
                value={[profile.fontSize]}
                onValueChange={([value]) => setProfile({ ...profile, fontSize: value ?? 18 })}
                aria-label="Type size"
              />
            </div>
            <div>
              <div className="mb-1 flex items-center justify-between text-sm">
                <Label>Line height</Label>
                <span className="tabular-nums text-muted">{profile.lineHeight.toFixed(1)}</span>
              </div>
              <Slider
                min={1.4}
                max={2.2}
                step={0.1}
                value={[profile.lineHeight]}
                onValueChange={([value]) => setProfile({ ...profile, lineHeight: value ?? 1.6 })}
                aria-label="Line height"
              />
            </div>
            <div>
              <div className="mb-1 flex items-center justify-between text-sm">
                <Label>Letter spacing</Label>
                <span className="tabular-nums text-muted">{profile.letterSpacing.toFixed(2)}</span>
              </div>
              <Slider
                min={0}
                max={0.12}
                step={0.01}
                value={[profile.letterSpacing]}
                onValueChange={([value]) => setProfile({ ...profile, letterSpacing: value ?? 0 })}
                aria-label="Letter spacing"
              />
            </div>
            <div>
              <div className="mb-1 flex items-center justify-between text-sm">
                <Label>Word spacing</Label>
                <span className="tabular-nums text-muted">{profile.wordSpacing.toFixed(2)}</span>
              </div>
              <Slider
                min={0}
                max={0.2}
                step={0.02}
                value={[profile.wordSpacing]}
                onValueChange={([value]) => setProfile({ ...profile, wordSpacing: value ?? 0 })}
                aria-label="Word spacing"
              />
            </div>
          </PanelWell>
        </Panel>

        <Panel>
          <PanelHeader title="Fixation" description="How strongly landing letters are marked, and whether the current line stays lit." />
          <PanelWell className="space-y-5 p-3">
            <div>
              <div className="mb-1 flex items-center justify-between text-sm">
                <Label>Strength</Label>
                <span className="tabular-nums text-muted">{Math.round(profile.bionicStrength * 100)}%</span>
              </div>
              <Slider
                min={0}
                max={0.8}
                step={0.05}
                value={[profile.bionicStrength]}
                onValueChange={([value]) => setProfile({ ...profile, bionicStrength: value ?? 0 })}
                aria-label="Fixation strength"
              />
            </div>
            <div>
              <p className="mb-2 text-xs font-medium tracking-wide text-muted uppercase">Rhythm</p>
              <div className="grid grid-cols-3 gap-1.5">
                {RHYTHM_CHOICES.map((curve) => (
                  <button
                    key={curve.id}
                    type="button"
                    aria-pressed={profile.rhythmCurve === curve.id}
                    onClick={() =>
                      setProfile({
                        ...profile,
                        rhythmCurve: curve.id,
                        rhythmOptimization: curve.id !== "steady",
                      })
                    }
                    className={cn(
                      "flex h-11 flex-col items-center justify-center rounded-md px-1",
                      profile.rhythmCurve === curve.id ? "bg-fg text-primary-fg" : "bg-fg/4 hover:bg-fg/8",
                    )}
                  >
                    <span className="text-sm font-medium">{curve.label}</span>
                  </button>
                ))}
              </div>
            </div>
            <div className="flex h-11 items-center justify-between px-1">
              <Label htmlFor="focus-line-settings">Focus line</Label>
              <Switch
                id="focus-line-settings"
                checked={profile.focusHighlight}
                onCheckedChange={(checked) => setProfile({ ...profile, focusHighlight: checked })}
              />
            </div>
            <div className="flex h-11 items-center justify-between px-1">
              <Label htmlFor="justify-settings">Justify text</Label>
              <Switch
                id="justify-settings"
                checked={profile.align === "justify"}
                onCheckedChange={(checked) => setProfile({ ...profile, align: checked ? "justify" : "left" })}
              />
            </div>
            <div className="flex h-11 items-center justify-between px-1">
              <Label htmlFor="syllables-settings">Syllables</Label>
              <Switch
                id="syllables-settings"
                checked={Boolean(profile.syllables)}
                onCheckedChange={(checked) => setProfile({ ...profile, syllables: checked })}
              />
            </div>
            <div className="flex h-11 items-center justify-between px-1">
              <Label htmlFor="letters-settings">Letter guide (b / d)</Label>
              <Switch
                id="letters-settings"
                checked={Boolean(profile.letterGuide)}
                onCheckedChange={(checked) => setProfile({ ...profile, letterGuide: checked })}
              />
            </div>
            <div className="flex h-11 items-center justify-between px-1">
              <Label htmlFor="words-settings">Word highlight</Label>
              <Switch
                id="words-settings"
                checked={Boolean(profile.wordGuide)}
                onCheckedChange={(checked) => setProfile({ ...profile, wordGuide: checked })}
              />
            </div>
            <div className="flex h-11 items-center justify-between px-1">
              <Label htmlFor="mask-settings">Focus window</Label>
              <Switch
                id="mask-settings"
                checked={Boolean(profile.readingMask)}
                onCheckedChange={(checked) => setProfile({ ...profile, readingMask: checked })}
              />
            </div>
            <div className="flex h-11 items-center justify-between px-1">
              <Label htmlFor="lookup-settings">Tap a word for its definition</Label>
              <Switch
                id="lookup-settings"
                checked={Boolean(profile.lookup)}
                onCheckedChange={(checked) => setProfile({ ...profile, lookup: checked })}
              />
            </div>
            <div>
              <div className="mb-1 flex items-center justify-between text-sm">
                <Label>Target pace</Label>
                <span className="tabular-nums text-muted">{targetWpm} WPM</span>
              </div>
              <Slider
                min={120}
                max={420}
                step={10}
                value={[targetWpm]}
                onValueChange={([value]) => setTargetWpm(value ?? 220)}
                aria-label="Target words per minute"
              />
            </div>
          </PanelWell>
        </Panel>

        <Panel>
          <PanelHeader title="Sound" description="A short opening tone when NeuroLens first loads in this tab." />
          <PanelWell className="flex h-14 items-center justify-between px-4">
            <Label htmlFor="opening-sound">Opening tone</Label>
            <Switch
              id="opening-sound"
              checked={sound}
              onCheckedChange={(checked) => {
                setSound(checked);
                setOpeningSoundEnabled(checked);
              }}
            />
          </PanelWell>
        </Panel>

        <Panel>
          <PanelHeader title="Saved setups" description="Apply a named setup, or keep the one you just tuned." />
          <PanelWell className="flex flex-col gap-1.5 p-2">
            {NAMED_PRESETS.map((preset) => (
              <Button
                key={preset.id}
                variant="outline"
                className="justify-between"
                onClick={() => {
                  applySavedProfile(preset);
                  toast.success(preset.name);
                }}
              >
                <span>{preset.name}</span>
                <span className="text-xs text-muted">{preset.targetWpm} WPM</span>
              </Button>
            ))}
            {savedProfiles.map((preset) => (
              <div key={preset.id} className="flex gap-2">
                <Button variant="outline" className="flex-1 justify-between" onClick={() => applySavedProfile(preset)}>
                  <span>{preset.name}</span>
                  <span className="text-xs text-muted">{preset.targetWpm} WPM</span>
                </Button>
                <Button variant="ghost" onClick={() => deleteSavedProfile(preset.id)}>
                  Remove
                </Button>
              </div>
            ))}
            <div className="mt-2 flex gap-2">
              <input
                value={profileName}
                onChange={(event) => setProfileName(event.target.value)}
                placeholder="Name this setup"
                aria-label="Name this setup"
                className="h-11 min-w-0 flex-1 rounded-md bg-bg px-3 text-sm shadow-border outline-none"
              />
              <Button
                variant="outline"
                onClick={() => {
                  if (!profileName.trim()) {
                    toast.error("Name this setup first");
                    return;
                  }
                  saveCurrentProfile(profileName);
                  setProfileName("");
                  toast.success("Setup saved");
                }}
              >
                Save
              </Button>
            </div>
          </PanelWell>
        </Panel>

        <Panel>
          <PanelHeader
            title="Reset"
            description="Hold to clear saved settings, notes, bookmarks, and reading history. Release to cancel."
          />
          <PanelWell className="px-4 py-4">
            <Button
              variant="destructive"
              className="relative overflow-hidden"
              onPointerDown={startHold}
              onPointerUp={endHold}
              onPointerLeave={endHold}
              onPointerCancel={endHold}
            >
              <span className="hold-fill absolute inset-0 bg-danger/20" data-holding={holding ? "true" : "false"} />
              <span className="relative">{holding ? "Hold to confirm" : "Clear local data"}</span>
            </Button>
          </PanelWell>
        </Panel>

        <Panel className="mb-8">
          <PanelHeader title="About NeuroLens" />
          <PanelWell className="px-4 py-4">
            <p className="text-sm leading-relaxed text-muted">
              An adaptive reading environment. Paste text, open a PDF page by page, look up a Bible chapter, search
              Project Gutenberg, or open a poem. Adaptive watches pace, pauses, rereads, and feel — it recommends, and
              it never silently rewrites a locked setting.
            </p>
            <p className="mt-4 text-xs text-subtle">Version 4.0 · WEB · Gutendex · PoetryDB</p>
          </PanelWell>
        </Panel>
      </div>
    </PageEnter>
  );
}
