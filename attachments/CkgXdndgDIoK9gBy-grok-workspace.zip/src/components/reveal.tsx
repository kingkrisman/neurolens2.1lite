import { useRef, type ReactNode } from "react";
import { useReducedMotion } from "motion/react";
import { cn } from "@/lib/utils";
import { easeInOut, easeOut, gsap, registerGsap, scrollerOf, useGSAP } from "@/lib/gsap";

registerGsap();

export function Reveal({
  children,
  className,
  delay = 0,
  variant = "rise",
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
  variant?: "rise" | "clip";
}) {
  const ref = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();

  useGSAP(
    () => {
      const el = ref.current;
      if (!el || reduce) return;
      const trigger = {
        trigger: el,
        scroller: scrollerOf(el),
        start: "top 88%",
        once: true,
      };
      if (variant === "clip") {
        gsap.fromTo(
          el,
          { clipPath: "inset(0 0 100% 0)" },
          {
            clipPath: "inset(0 0 0 0)",
            duration: 0.7,
            delay: delay / 1000,
            ease: easeInOut,
            immediateRender: false,
            scrollTrigger: trigger,
          },
        );
        return;
      }
      gsap.fromTo(
        el,
        { y: 16 },
        {
          y: 0,
          duration: 0.45,
          delay: delay / 1000,
          ease: easeOut,
          immediateRender: false,
          clearProps: "transform",
          scrollTrigger: trigger,
        },
      );
    },
    { dependencies: [delay, variant, reduce] },
  );

  return (
    <div
      ref={ref}
      className={cn(variant === "clip" ? "reveal" : "gsap-enter", className)}
    >
      {children}
    </div>
  );
}
