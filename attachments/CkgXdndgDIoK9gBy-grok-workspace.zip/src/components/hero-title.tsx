import { useRef } from "react";
import { useReducedMotion } from "motion/react";
import { easeOut, gsap, registerGsap, useGSAP } from "@/lib/gsap";

registerGsap();

export function HeroTitle() {
  const ref = useRef<HTMLHeadingElement>(null);
  const reduce = useReducedMotion();

  useGSAP(
    () => {
      const root = ref.current;
      if (!root || reduce) return;
      gsap.from(root, { y: 12, duration: 0.45, ease: easeOut, clearProps: "transform" });
    },
    { dependencies: [reduce] },
  );

  return (
    <h1 ref={ref} className="max-w-lg text-4xl leading-[1.08] sm:text-5xl">
      Read with <em className="font-medium italic">effortless</em> clarity.
    </h1>
  );
}
