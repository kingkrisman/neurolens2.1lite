import { useMemo } from "react";
import { AccessibleBionic } from "@/components/accessible-bionic";
import { decorateWord, tokenizeWords } from "@/lib/word-markup";
import { cn } from "@/lib/utils";

export function WordRun({
  text,
  html,
  lineIdx,
  activeWord,
  guides,
  bionic,
  rhythm,
  onWord,
}: {
  text: string;
  html: string;
  lineIdx: number;
  activeWord: { line: number; index: number } | null;
  guides: { syllables: boolean; letterGuide: boolean; wordGuide: boolean; lookup: boolean };
  bionic: number;
  rhythm: boolean;
  onWord: (line: number, index: number, word: string, openLookup: boolean) => void;
}) {
  const heavy = guides.syllables || guides.letterGuide || guides.wordGuide || guides.lookup;
  const tokens = useMemo(() => (heavy ? tokenizeWords(text) : []), [heavy, text]);

  if (!heavy) return <AccessibleBionic text={text} html={html} />;

  let wordIndex = -1;
  return (
    <>
      <span aria-hidden="true">
        {tokens.map((token, i) => {
          if (!token.isWord) return <span key={i}>{token.raw}</span>;
          wordIndex += 1;
          const index = wordIndex;
          const current = activeWord?.line === lineIdx && activeWord.index === index;
          return (
            <span
              key={i}
              role="button"
              tabIndex={0}
              data-word={`${lineIdx}-${index}`}
              className={cn("reading-word", current && "is-current")}
              onClick={(event) => {
                event.stopPropagation();
                onWord(lineIdx, index, token.raw, true);
              }}
              onKeyDown={(event) => {
                if (event.key === "Enter" || event.key === " ") {
                  event.preventDefault();
                  onWord(lineIdx, index, token.raw, true);
                }
              }}
              onMouseEnter={() => {
                if (guides.wordGuide) onWord(lineIdx, index, token.raw, false);
              }}
            >
              <span
                dangerouslySetInnerHTML={{
                  __html: decorateWord(token.raw, {
                    bionic,
                    syllables: guides.syllables,
                    letterGuide: guides.letterGuide,
                    rhythm,
                  }),
                }}
              />
            </span>
          );
        })}
      </span>
      <span className="sr-only">{text}</span>
    </>
  );
}
