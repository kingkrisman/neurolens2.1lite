import { useEffect, useRef, type ReactNode } from "react";
import { useReducedMotion } from "motion/react";
import { Toaster } from "sonner";
import { Search } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { TABS } from "@/lib/types";
import { isDarkScheme } from "@/lib/scheme";
import { CVD_LABELS } from "@/lib/color-vision";
import { useAppStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Kbd } from "@/components/ui/surfaces";
import { TooltipProvider } from "@/components/ui/tooltip";
import { CommandPalette } from "@/components/command-palette";
import { Landing } from "@/components/landing";
import { Library } from "@/components/library";
import { Insights } from "@/components/insights";
import { SettingsPanel } from "@/components/settings-panel";
import { Reader } from "@/components/reader";
import { Mark } from "@/components/mark";
import { Segmented } from "@/components/segmented";
import { LiveAnnouncer } from "@/components/live-announcer";
import { Opening } from "@/components/opening";
import { cn } from "@/lib/utils";
import { easeOut, gsap, refreshScroll, registerGsap, ScrollTrigger, useGSAP } from "@/lib/gsap";

registerGsap();

const HAS_SCROLL_TIMELINE =
  typeof CSS !== "undefined" && CSS.supports("animation-timeline: scroll()");

function Pane({
  children,
  className,
  onProgress,
}: {
  children: ReactNode;
  className?: string;
  onProgress?: (value: number) => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const progress = useRef(onProgress);
  progress.current = onProgress;

  useGSAP(
    () => {
      const node = ref.current;
      const inner = node?.firstElementChild;
      if (!node || !inner) return;
      const trigger = ScrollTrigger.create({
        scroller: node,
        trigger: inner,
        start: "top top",
        end: "bottom bottom",
        onUpdate: (self) => progress.current?.(self.progress),
      });
      return () => trigger.kill();
    },
    { dependencies: [] },
  );

  return (
    <div
      ref={ref}
      className={cn("pane-scroll h-full overflow-y-auto", className)}
      onScroll={() => {
        if (HAS_SCROLL_TIMELINE) return;
        const node = ref.current;
        if (!node || !progress.current) return;
        const remaining = node.scrollHeight - node.clientHeight;
        progress.current(remaining > 1 ? Math.min(1, node.scrollTop / remaining) : 1);
      }}
    >
      <div className="min-h-full pt-14 sm:pt-16">{children}</div>
    </div>
  );
}

export function AppShell() {
  const hydrate = useAppStore((s) => s.hydrate);
  const tab = useAppStore((s) => s.tab);
  const direction = useAppStore((s) => s.direction);
  const setTab = useAppStore((s) => s.setTab);
  const text = useAppStore((s) => s.text);
  const setCommandOpen = useAppStore((s) => s.setCommandOpen);
  const theme = useAppStore((s) => s.profile.theme);
  const dimChrome = useAppStore((s) => s.profile.dimChrome);
  const cvdPreview = useAppStore((s) => s.cvdPreview);
  const setCvdPreview = useAppStore((s) => s.setCvdPreview);
  const reduceMotion = useReducedMotion();
  const progressRef = useRef(0);
  const headerRef = useRef<HTMLElement>(null);
  const footerRef = useRef<HTMLElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  useEffect(() => {
    const stopNav = (event: DragEvent) => {
      if (!event.dataTransfer || ![...event.dataTransfer.types].includes("Files")) return;
      event.preventDefault();
    };
    window.addEventListener("dragover", stopNav);
    window.addEventListener("drop", stopNav);
    return () => {
      window.removeEventListener("dragover", stopNav);
      window.removeEventListener("drop", stopNav);
    };
  }, []);

  useEffect(() => {
    const label = TABS.find((item) => item.id === tab)?.label ?? "Explore";
    document.title = tab === "explore" ? "NeuroLens" : `${label} · NeuroLens`;
  }, [tab]);

  useEffect(() => {
    progressRef.current = 0;
    document.documentElement.style.setProperty("--scroll-progress", "0");
    refreshScroll();
  }, [tab]);

  useGSAP(
    () => {
      if (reduceMotion) return;
      const header = headerRef.current;
      const footer = footerRef.current;
      if (header) gsap.from(header, { y: -14, duration: 0.45, ease: easeOut, clearProps: "transform" });
      if (footer) gsap.from(footer, { y: 10, duration: 0.4, delay: 0.08, ease: easeOut, clearProps: "transform" });
    },
    { dependencies: [reduceMotion] },
  );

  useGSAP(
    () => {
      const stage = stageRef.current;
      if (!stage) return;
      if (reduceMotion) {
        gsap.set(stage, { x: 0, opacity: 1 });
        return;
      }
      gsap.fromTo(
        stage,
        { x: direction >= 0 ? 14 : -14 },
        { x: 0, duration: 0.28, ease: easeOut, clearProps: "transform" },
      );
    },
    { dependencies: [tab, direction, reduceMotion] },
  );

  const toastTheme = isDarkScheme(theme) ? "dark" : "light";

  function setProgress(value: number) {
    progressRef.current = value;
    if (HAS_SCROLL_TIMELINE) return;
    document.documentElement.style.setProperty("--scroll-progress", String(value));
  }

  return (
    <TooltipProvider>
      <div className={cn("nl-shell relative flex h-dvh flex-col overflow-hidden bg-bg text-fg", tab === "read" && dimChrome && "is-reading-dim")}>
        <Opening />
        <a href="#main-content" className="skip-link">
          Skip to content
        </a>
        <div className="grain" aria-hidden />
        <header ref={headerRef} className="material pointer-events-none absolute inset-x-0 top-0 z-40">
          <div className="pointer-events-auto flex h-14 items-center gap-1.5 px-2 sm:h-16 sm:gap-2 sm:px-6">
            <button
              type="button"
              aria-label="NeuroLens home"
              className="flex shrink-0 items-center gap-2.5 text-fg"
              onClick={() => setTab("explore")}
            >
              <Mark className="size-7 text-fg" />
              <span className="hidden text-sm font-medium tracking-tight sm:inline">NeuroLens</span>
            </button>
            <nav aria-label="Primary" className="min-w-0 flex-1 overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
              <Segmented
                tone="nav"
                value={tab}
                onChange={setTab}
                options={TABS.map((item) => ({
                  id: item.id,
                  label: item.label,
                  disabled: item.id === "read" && !text,
                }))}
                className="mx-auto h-10 w-max max-w-full"
              />
            </nav>
            {cvdPreview !== "none" && (
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="hidden sm:inline-flex"
                aria-label={`Turn off ${CVD_LABELS[cvdPreview]} simulation`}
                onClick={() => setCvdPreview("none")}
              >
                {CVD_LABELS[cvdPreview]}
              </Button>
            )}
            <Button
              variant="outline"
              size="sm"
              className="hidden sm:inline-flex"
              onClick={() => setCommandOpen(true)}
            >
              <Search size={14} />
              Search
              <Kbd>⌘K</Kbd>
            </Button>
            <Button
              variant="outline"
              size="icon-sm"
              className="sm:hidden"
              aria-label="Search"
              onClick={() => setCommandOpen(true)}
            >
              <Search size={16} />
            </Button>
          </div>
          <div
            aria-hidden
            className="scroll-progress pointer-events-none h-0.5 bg-fg/35"
          />
          <div
            aria-hidden
            className="pointer-events-none h-6 bg-gradient-to-b from-bg/80 to-transparent"
          />
        </header>

        <main
          id="main-content"
          tabIndex={-1}
          aria-label={TABS.find((item) => item.id === tab)?.label ?? "Explore"}
          className="relative min-h-0 flex-1 outline-none"
        >
          <div ref={stageRef} className="absolute inset-0 overflow-hidden">
              {tab === "explore" && (
                <Pane onProgress={setProgress}>
                  <Landing />
                </Pane>
              )}
              {tab === "read" && <Reader />}
              {tab === "library" && (
                <Pane onProgress={setProgress}>
                  <Library />
                </Pane>
              )}
              {tab === "insights" && (
                <Pane onProgress={setProgress}>
                  <Insights />
                </Pane>
              )}
              {tab === "settings" && (
                <Pane onProgress={setProgress}>
                  <SettingsPanel />
                </Pane>
              )}
          </div>
        </main>

        <footer ref={footerRef} className="flex min-h-12 shrink-0 flex-col items-center justify-center gap-2 px-4 py-3 text-center text-xs text-muted sm:flex-row sm:gap-4">
          <span>NeuroLens · Crafted for neurodivergent minds</span>
          <span className="hidden opacity-40 sm:inline" aria-hidden>
            ·
          </span>
          <nav aria-label="Legal" className="flex items-center gap-3">
            <Link to="/privacy" className="hover:text-fg">
              Privacy
            </Link>
            <Link to="/thank-you" className="hover:text-fg">
              Thank you
            </Link>
          </nav>
        </footer>
        <LiveAnnouncer />
        <CommandPalette />
        <Toaster
          theme={toastTheme}
          position="bottom-right"
          offset={24}
          mobileOffset={16}
          visibleToasts={3}
          gap={10}
          toastOptions={{
            classNames: {
              toast: "!bg-surface !text-fg !border-0 !shadow-[var(--shadow-float)] !rounded-[16px]",
              title: "!text-sm !font-medium !text-fg",
              description: "!text-sm !text-muted",
            },
          }}
        />
      </div>
    </TooltipProvider>
  );
}
