import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { READING_PROFILES } from "./types.ts";
import { buildSuggestions, formatDuration } from "./insights.ts";

describe("insights", () => {
  it("formats sitting time", () => {
    assert.equal(formatDuration(4000), "4s");
    assert.equal(formatDuration(125000), "2m 5s");
  });

  it("offers a sample when the log is empty", () => {
    const suggestions = buildSuggestions({
      sessions: [],
      reading: {
        progress: 0,
        wordCount: 0,
        wordsRead: 0,
        elapsedActiveMs: 0,
        currentWpm: null,
        pauses: [],
        rereads: [],
        startedAt: null,
      },
      profile: READING_PROFILES.default,
      mode: "default",
      targetWpm: 220,
      feel: null,
    });
    assert.equal(suggestions[0]?.id, "sample");
  });

  it("recommends focus line after rereads", () => {
    const suggestions = buildSuggestions({
      sessions: [
        {
          title: "A sitting",
          content: "Hello",
          openedAt: Date.now(),
          rereadCount: 3,
          currentWpm: 180,
        },
      ],
      reading: {
        progress: 0.4,
        wordCount: 400,
        wordsRead: 160,
        elapsedActiveMs: 40_000,
        currentWpm: 180,
        pauses: [],
        rereads: [],
        startedAt: Date.now(),
      },
      profile: READING_PROFILES.default,
      mode: "default",
      targetWpm: 220,
      feel: null,
    });
    assert.ok(suggestions.some((item) => item.id === "focus"));
  });
});
