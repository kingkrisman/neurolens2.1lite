import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { chunkByMinutes, decorateWord, wordAtChar } from "./word-markup.ts";

describe("word markup", () => {
  it("marks syllables inside constitution", () => {
    const html = decorateWord("constitution", { syllables: true });
    assert.match(html, /syl-dot/);
    assert.match(html, /con/);
  });

  it("color-codes confusing letters", () => {
    const html = decorateWord("bed", { letterGuide: true });
    assert.match(html, /letter-b/);
    assert.match(html, /letter-d/);
  });

  it("maps speech char index onto a word", () => {
    assert.equal(wordAtChar("The cat sat.", 4), 1);
  });

  it("chunks a long passage by minutes", () => {
    const words = Array.from({ length: 900 }, (_, i) => `word${i}`).join(" ");
    const chunks = chunkByMinutes(words, 200, 3);
    assert.ok(chunks.length >= 2);
  });
});
