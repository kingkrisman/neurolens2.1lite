import { processBionicText } from "./bionic.ts";
import { syllabify } from "./syllables.ts";

const CLUSTERS = /^(sch|scr|spl|spr|str|thr|chr|shr|th|sh|ch|wh|ph|ck|ng|qu)/i;
const CONFUSING = new Set(["b", "d", "p", "q"]);

export interface WordToken {
  text: string;
  html: string;
  index: number;
  charStart: number;
}

export function tokenizeWords(text: string): { raw: string; isWord: boolean; charStart: number }[] {
  const parts: { raw: string; isWord: boolean; charStart: number }[] = [];
  const re = /([A-Za-z][A-Za-z']*)|([^A-Za-z]+)/g;
  let match: RegExpExecArray | null;
  while ((match = re.exec(text))) {
    parts.push({
      raw: match[0],
      isWord: Boolean(match[1]),
      charStart: match.index,
    });
  }
  return parts;
}

export function decorateWord(
  word: string,
  {
    bionic = 0,
    syllables = false,
    letterGuide = false,
    rhythm = false,
  }: { bionic?: number; syllables?: boolean; letterGuide?: boolean; rhythm?: boolean } = {},
): string {
  const letters = word.match(/^([^A-Za-z]*)([A-Za-z']+)([^A-Za-z]*)$/);
  if (!letters) return escapeHtml(word);
  const [, lead, core, trail] = letters;
  const bounds = syllables ? syllableBounds(core) : [];
  const bionicHtml = bionic > 0 ? processBionicText(core, bionic, rhythm) : escapeHtml(core);
  const boldMatch = bionicHtml.match(/^<span class="fixation">([^<]*)<\/span>(.*)$/);
  const boldLen = boldMatch ? boldMatch[1].length : 0;
  let html = escapeHtml(lead);
  for (let i = 0; i < core.length; i += 1) {
    if (bounds.includes(i) && i > 0) html += '<span class="syl-dot" aria-hidden="true">·</span>';
    const ch = core[i] ?? "";
    const cluster = letterGuide ? clusterAt(core, i) : null;
    let piece = escapeHtml(ch);
    if (cluster) {
      piece = `<span class="letter-cluster">${piece}</span>`;
    } else if (letterGuide && CONFUSING.has(ch.toLowerCase())) {
      piece = `<span class="letter-${ch.toLowerCase()}">${piece}</span>`;
    }
    if (i < boldLen) piece = `<span class="fixation">${piece}</span>`;
    html += piece;
    if (cluster) i += cluster.length - 1;
  }
  return html + escapeHtml(trail);
}

export function decorateSentence(
  text: string,
  opts: { bionic?: number; syllables?: boolean; letterGuide?: boolean; rhythm?: boolean },
): WordToken[] {
  let wordIndex = 0;
  return tokenizeWords(text)
    .filter((part) => part.isWord)
    .map((part) => ({
      text: part.raw,
      html: decorateWord(part.raw, opts),
      index: wordIndex++,
      charStart: part.charStart,
    }));
}

function syllableBounds(core: string): number[] {
  const parts = syllabify(core);
  const at: number[] = [];
  let cursor = 0;
  for (let i = 1; i < parts.length; i += 1) {
    cursor += parts[i - 1]?.length ?? 0;
    at.push(cursor);
  }
  return at;
}

function clusterAt(word: string, index: number): string | null {
  const slice = word.slice(index);
  const hit = slice.match(CLUSTERS);
  return hit ? hit[1] : null;
}

function escapeHtml(value: string): string {
  return value.replace(/&/g, "\u0026amp;").replace(/</g, "\u0026lt;").replace(/>/g, "\u0026gt;");
}

export function wordAtChar(text: string, charIndex: number): number {
  const tokens = tokenizeWords(text).filter((part) => part.isWord);
  let found = 0;
  for (let i = 0; i < tokens.length; i += 1) {
    const token = tokens[i];
    if (!token) continue;
    if (charIndex >= token.charStart) found = i;
  }
  return found;
}

export function chunkByMinutes(text: string, wpm: number, minutes = 3): string[] {
  const target = Math.max(80, Math.round(wpm * minutes));
  const units = text.split(/\n{2,}|(?<=[.!?])\s+/);
  const chunks: string[] = [];
  let bucket: string[] = [];
  let count = 0;
  const flush = () => {
    if (!bucket.length) return;
    chunks.push(bucket.join(" ").replace(/\s+/g, " ").trim());
    bucket = [];
    count = 0;
  };
  for (const unit of units) {
    const words = unit.trim().split(/\s+/).filter(Boolean).length;
    if (!words) continue;
    if (count && count + words > target) flush();
    if (words > target) {
      const tokens = unit.trim().split(/\s+/);
      for (let i = 0; i < tokens.length; i += target) {
        if (count) flush();
        chunks.push(tokens.slice(i, i + target).join(" "));
      }
      continue;
    }
    bucket.push(unit.trim());
    count += words;
  }
  flush();
  return chunks.length ? chunks : [text];
}
