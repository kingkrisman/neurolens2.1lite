import { bestContrastTheme, evaluateScheme } from "./contrast.ts";
import { SAMPLE_TEXTS } from "./samples.ts";
import type { ReadingFeel, ReadingMode, ReadingProfile, Session } from "./types.ts";
import type { ReadingSnapshot } from "./store.ts";

export type InsightKind = "focus" | "wpm-down" | "wpm-up" | "contrast" | "lexend" | "adaptive" | "sample";

export interface InsightSuggestion {
  id: InsightKind;
  title: string;
  body: string;
  cta: string;
}

export function formatDuration(ms: number): string {
  const seconds = Math.max(0, Math.round(ms / 1000));
  if (seconds < 60) return `${seconds}s`;
  const minutes = Math.floor(seconds / 60);
  const rest = seconds % 60;
  return rest ? `${minutes}m ${rest}s` : `${minutes}m`;
}

export function average(values: number[]): number | null {
  const clean = values.filter((value) => Number.isFinite(value));
  if (!clean.length) return null;
  return Math.round(clean.reduce((sum, value) => sum + value, 0) / clean.length);
}

export function buildSuggestions({
  sessions,
  reading,
  profile,
  mode,
  targetWpm,
  feel,
}: {
  sessions: Session[];
  reading: ReadingSnapshot;
  profile: ReadingProfile;
  mode: ReadingMode;
  targetWpm: number;
  feel: ReadingFeel | null;
}): InsightSuggestion[] {
  const out: InsightSuggestion[] = [];
  const last = sessions[0];
  const wpm = last?.currentWpm ?? reading.currentWpm;
  const rereads = last?.rereadCount ?? reading.rereads.length;
  const pauses = last?.pauseCount ?? reading.pauses.length;
  const contrast = evaluateScheme(profile.theme, profile.fontSize);

  if (!sessions.length && !reading.startedAt) {
    out.push({
      id: "sample",
      title: "Start a first sitting",
      body: `Open “${SAMPLE_TEXTS[0].title}” and read a page. Insights fill from pace, pauses, and how the page felt.`,
      cta: "Open a sample",
    });
  }

  if (feel === "slow" || (wpm != null && wpm < targetWpm * 0.72)) {
    out.push({
      id: "wpm-down",
      title: "Lower the target pace",
      body: `This sitting ran behind ${targetWpm} WPM. A slower target gives the line more room.`,
      cta: `Set ${Math.max(120, targetWpm - 20)} WPM`,
    });
  } else if (feel === "fast" || (wpm != null && wpm > targetWpm * 1.15 && rereads < 1)) {
    out.push({
      id: "wpm-up",
      title: "You can raise the target",
      body: "Pace held without rereads. A slightly higher target keeps auto-scroll honest.",
      cta: `Set ${Math.min(420, targetWpm + 15)} WPM`,
    });
  }

  if (rereads >= 2 && !profile.focusHighlight) {
    out.push({
      id: "focus",
      title: "Turn on the focus line",
      body: "You moved back through the page more than once. Lighting the current line makes re-entry cheaper.",
      cta: "Enable focus line",
    });
  }

  if (pauses >= 2 && profile.fontFamily === "sans") {
    out.push({
      id: "lexend",
      title: "Try a quieter typeface",
      body: "Long pauses often mean the letters are working too hard. Lexend lowers crowding without rewriting the prose.",
      cta: "Use Lexend",
    });
  }

  if (contrast.bodyLevel === "fail" || (rereads >= 2 && profile.theme === "paper")) {
    const next = bestContrastTheme(profile.theme);
    if (next !== profile.theme) {
      out.push({
        id: "contrast",
        title: "Raise the ink",
        body: `Body contrast is ${contrast.body.toFixed(1)}:1 at ${profile.fontSize}px. ${next === "ink" ? "Ink" : "Contrast"} keeps your room and darkens the type.`,
        cta: `Switch to ${next === "ink" ? "Ink" : "Contrast"}`,
      });
    }
  }

  if (mode !== "adaptive" && sessions.length > 0) {
    out.push({
      id: "adaptive",
      title: "Let Adaptive watch a sitting",
      body: "It recommends pace, spacing, and contrast. It will not silently rewrite a locked setting.",
      cta: "Turn on Adaptive",
    });
  }

  return out.slice(0, 3);
}
