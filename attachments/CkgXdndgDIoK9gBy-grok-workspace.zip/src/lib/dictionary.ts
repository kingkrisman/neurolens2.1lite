export interface WordSense {
  word: string;
  phonetic: string;
  definition: string;
  partOfSpeech: string;
  audio: string | null;
}

const cache = new Map<string, WordSense | null>();

export async function lookupWord(raw: string): Promise<WordSense | null> {
  const word = raw.toLowerCase().replace(/[^a-z']/g, "");
  if (word.length < 2) return null;
  if (cache.has(word)) return cache.get(word) ?? null;
  try {
    const response = await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(word)}`);
    if (!response.ok) {
      cache.set(word, null);
      return null;
    }
    const data = (await response.json()) as Array<{
      word?: string;
      phonetic?: string;
      phonetics?: { text?: string; audio?: string }[];
      meanings?: { partOfSpeech?: string; definitions?: { definition?: string }[] }[];
    }>;
    const entry = data[0];
    const meaning = entry?.meanings?.[0];
    const sense: WordSense = {
      word: entry?.word ?? word,
      phonetic: entry?.phonetic || entry?.phonetics?.find((item) => item.text)?.text || "",
      definition: meaning?.definitions?.[0]?.definition ?? "",
      partOfSpeech: meaning?.partOfSpeech ?? "",
      audio: entry?.phonetics?.find((item) => item.audio)?.audio || null,
    };
    cache.set(word, sense.definition ? sense : null);
    return cache.get(word) ?? null;
  } catch {
    cache.set(word, null);
    return null;
  }
}

export function speakWord(word: string) {
  if (!("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(word);
  utterance.rate = 0.85;
  window.speechSynthesis.speak(utterance);
}
