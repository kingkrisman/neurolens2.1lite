import { createFileRoute } from "@tanstack/react-router";

const GUTENDEX_ORIGIN = "https://gutendex.com";
const USER_AGENT = "NeuroLens/1.0 (adaptive reader; Project Gutenberg via Gutendex)";

function isAllowedSplat(splat: string): boolean {
  return splat === "books" || /^books\/\d+$/.test(splat);
}

export const Route = createFileRoute("/api/gutendex/$")({
  server: {
    handlers: {
      GET: async ({ params, request }) => {
        const splat = params._splat ?? "";
        if (!isAllowedSplat(splat)) {
          return new Response("Not found", { status: 404 });
        }

        const incoming = new URL(request.url);
        const target = new URL(`${GUTENDEX_ORIGIN}/${splat}`);
        incoming.searchParams.forEach((value, key) => {
          target.searchParams.set(key, value);
        });

        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 8_000);
        try {
          const response = await fetch(target, {
            signal: controller.signal,
            headers: {
              Accept: "application/json",
              "User-Agent": USER_AGENT,
            },
          });
          const body = await response.arrayBuffer();
          const headers = new Headers();
          headers.set("content-type", response.headers.get("content-type") ?? "application/json");
          headers.set("cache-control", response.ok ? "public, max-age=180" : "no-store");
          return new Response(body, { status: response.status, headers });
        } catch {
          return Response.json({ error: "Gutendex is unavailable." }, { status: 502 });
        } finally {
          clearTimeout(timer);
        }
      },
    },
  },
});
